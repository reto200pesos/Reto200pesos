import { Product } from '../types';

export const products: Product[] = [
  {
    id: '1',
    name: 'Wireless Noise-Canceling Headphones',
    description: 'Premium over-ear headphones with advanced noise cancellation technology and 30-hour battery life.',
    price: 199.99,
    originalPrice: 299.99,
    images: [
      'https://images.pexels.com/photos/3394650/pexels-photo-3394650.jpeg',
      'https://images.pexels.com/photos/1649771/pexels-photo-1649771.jpeg'
    ],
    category: 'Electronics',
    stock: 15,
    maxStock: 50,
    badge: 'bestseller',
    rating: 4.8,
    reviews: 2847
  },
  {
    id: '2',
    name: 'Smart Fitness Watch',
    description: 'Advanced fitness tracker with heart rate monitoring, GPS, and 7-day battery life.',
    price: 249.99,
    originalPrice: 349.99,
    images: [
      'https://images.pexels.com/photos/437037/pexels-photo-437037.jpeg',
      'https://images.pexels.com/photos/1034063/pexels-photo-1034063.jpeg'
    ],
    category: 'Electronics',
    stock: 3,
    maxStock: 25,
    badge: 'low-stock',
    rating: 4.6,
    reviews: 1923
  },
  {
    id: '3',
    name: 'Premium Coffee Maker',
    description: 'Professional-grade coffee machine with built-in grinder and programmable brewing settings.',
    price: 179.99,
    images: [
      'https://images.pexels.com/photos/324028/pexels-photo-324028.jpeg'
    ],
    category: 'Appliances',
    stock: 8,
    maxStock: 20,
    badge: 'new-arrival',
    rating: 4.7,
    reviews: 456
  },
  {
    id: '4',
    name: 'Ergonomic Office Chair',
    description: 'Adjustable lumbar support chair with breathable mesh and premium cushioning.',
    price: 299.99,
    originalPrice: 399.99,
    images: [
      'https://images.pexels.com/photos/1957477/pexels-photo-1957477.jpeg'
    ],
    category: 'Furniture',
    stock: 12,
    maxStock: 30,
    rating: 4.5,
    reviews: 789
  },
  {
    id: '5',
    name: 'Wireless Gaming Mouse',
    description: 'High-precision gaming mouse with customizable RGB lighting and ultra-fast response time.',
    price: 79.99,
    originalPrice: 99.99,
    images: [
      'https://images.pexels.com/photos/2115256/pexels-photo-2115256.jpeg'
    ],
    category: 'Electronics',
    stock: 25,
    maxStock: 40,
    badge: 'bestseller',
    rating: 4.9,
    reviews: 3456
  },
  {
    id: '6',
    name: 'Portable Bluetooth Speaker',
    description: 'Waterproof speaker with 360-degree sound and 24-hour battery life.',
    price: 89.99,
    originalPrice: 129.99,
    images: [
      'https://images.pexels.com/photos/1279330/pexels-photo-1279330.jpeg'
    ],
    category: 'Electronics',
    stock: 2,
    maxStock: 15,
    badge: 'low-stock',
    rating: 4.4,
    reviews: 1234
  }
];