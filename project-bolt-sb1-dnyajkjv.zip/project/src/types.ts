export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  originalPrice?: number;
  images: string[];
  category: string;
  stock: number;
  maxStock: number;
  badge?: 'bestseller' | 'low-stock' | 'new-arrival';
  rating: number;
  reviews: number;
}

export interface CartItem {
  product: Product;
  quantity: number;
}

export interface ToastNotification {
  id: string;
  message: string;
  type: 'success' | 'error' | 'info';
  duration?: number;
}

export interface FilterOptions {
  category: string;
  priceRange: [number, number];
  inStock: boolean;
  sortBy: 'name' | 'price-low' | 'price-high' | 'rating';
}